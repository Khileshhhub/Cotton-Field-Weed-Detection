# CottonWeedID15 > 2022-10-23 9:34pm
https://universe.roboflow.com/weed-pp05h/cottonweedid15

Provided by a Roboflow user
License: CC BY 4.0

